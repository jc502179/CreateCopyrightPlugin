=== Create Copyright Plugin ===
Author: Yi
Vision: 1.0.0
License: GPLv2 or later

== Description ==
This plugin is my first time develop plugin.
== Installation ==
Upload the copyright plugin to your website, then Activate it.
== Vision log ==

= 1.0.0 =
*Release Date - 20 January 2019*

* The initial version released
